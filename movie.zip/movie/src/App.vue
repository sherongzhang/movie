<template>
  <div id="app">
    <van-tabbar v-model="active" v-show="$store.state.vanTabbar">
      <van-tabbar-item to="/mv/hot" icon="video-o">电影</van-tabbar-item>
      <van-tabbar-item to="/cinema" icon="wap-home-o">影院</van-tabbar-item>
      <van-tabbar-item to="/my/meituan" icon="user-o">我的</van-tabbar-item>
    </van-tabbar>

    <!-- 路由模块 -->
    <transition mode="out-in" :duration="{ enter: 400, leave: 400 }" enter-active-class="animated fadeIn"  leave-active-class="animated fadeOut">
            <router-view></router-view>
		</transition>
    
  </div>
</template>

<script>
  export default {
      data:function(){
        return {
          active:0,
        }
      },
      
  }
</script>

<style lang="scss" scoped>
    *{
      padding:0px;
      margin:0px;
    }
    .bottomnull{
    height: 50px;
    width: 100%;
  }
  //解决滚动条效果 , 边界问题
    #app{
        overflow: hidden;
    }
</style>
