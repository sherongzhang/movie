import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

Vue.config.productionTip = false

//引入vant
import vant from "vant";
import "vant/lib/index.css";
Vue.use(vant);

//引入swiper
import 'swiper/css/swiper.css';

//引入动画
import "animate.css";

//引入node.js后台 npm i express -S

// var express = require("express");
// var app = express();
// //注册接口

// app.get("/register",function(req,res){
//   res.send("注册")
// })
// //注册接口
// app.get("/",function(req,res){
//   res.send("hi")
// })


// app.listen(3000,"127.0.0.1",()=>{
//   console.log("请访问:http://127.0.0.1:3000")
// })


new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
