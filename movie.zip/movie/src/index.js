var express = require("express");
var app = express();
//注册接口

app.get("/register",function(req,res){
  res.send("注册")
})
//注册接口
app.get("/",function(req,res){
  res.send("hi")
})


app.listen(3000,"127.0.0.1",()=>{
  console.log("请访问:http://127.0.0.1:3000")
})