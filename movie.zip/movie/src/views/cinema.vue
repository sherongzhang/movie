<template>
    <div>
        <div class="top"> 
            <van-row>
                <van-col span="3">
                    <i @click="$router.go(-1)"><van-icon name="arrow-left"/></i>   
                </van-col>
                <van-col span="18">影院</van-col>
                <van-col span="3">
                    <!-- <i><van-icon name="ellipsis" /></i> -->
                 </van-col>
            </van-row>
        </div> 
        <div class="searchBar">
             <van-row>
                <van-col span="4">
                    <router-link to="/mv/hot" tag="span" class="place">黑袍</router-link>
                </van-col>
                <van-col span="20"><van-search placeholder="搜影院"/></van-col>            
            </van-row>
        </div>
           
            <div class="cinema">
                <div class="shanghaiCinema" @click="$router.push({path:'/shanghai'})">
                    <p class="cinemaName">
                        UA电影城（上海梅龙镇广场店）
                    </p>
                    <p class="cinemaWhere">
                        静安区南京西路1038号梅龙镇广场10楼（近江宁路） <span class="how-far">666km</span>
                    </p>
                    <div class="activity"> <span>退</span><span>改签</span><span>小吃</span><span>折扣卡</span></div>
                   
                </div>
                <div class="shanghaiCinema" @click="$router.push({path:'/shanghai'})">
                    <p class="cinemaName">
                        UA电影城（上海梅龙镇广场店）
                    </p>
                    <p class="cinemaWhere">
                        静安区南京西路1038号梅龙镇广场10楼（近江宁路） <span class="how-far">666km</span>
                    </p>
                    <div class="activity"> <span>退</span><span>改签</span><span>小吃</span><span>折扣卡</span></div>
                   
                </div>
                <div class="shanghaiCinema" @click="$router.push({path:'/shanghai'})">
                    <p class="cinemaName">
                        UA电影城（上海梅龙镇广场店）
                    </p>
                    <p class="cinemaWhere">
                        静安区南京西路1038号梅龙镇广场10楼（近江宁路） <span class="how-far">666km</span>
                    </p>
                    <div class="activity"> <span>退</span><span>改签</span><span>小吃</span><span>折扣卡</span></div>
                   
                </div>
                <div class="shanghaiCinema" @click="$router.push({path:'/shanghai'})">
                    <p class="cinemaName">
                        UA电影城（上海梅龙镇广场店）
                    </p>
                    <p class="cinemaWhere">
                        静安区南京西路1038号梅龙镇广场10楼（近江宁路） <span class="how-far">666km</span>
                    </p>
                    <div class="activity"> <span>退</span><span>改签</span><span>小吃</span><span>折扣卡</span></div>
                   
                </div>
                <div class="shanghaiCinema" @click="$router.push({path:'/shanghai'})">
                    <p class="cinemaName">
                        UA电影城（上海梅龙镇广场店）
                    </p>
                    <p class="cinemaWhere">
                        静安区南京西路1038号梅龙镇广场10楼（近江宁路） <span class="how-far">666km</span>
                    </p>
                    <div class="activity"> <span>退</span><span>改签</span><span>小吃</span><span>折扣卡</span></div>
                   
                </div>
            </div>
    </div>
</template>

<script>
     export default {
        data() {
            return {
            active: 0
            };
        },
        created(){
            this.$store.state.vanTabbar = false;
        },
       
        destroyed() {
            this.$store.state.vanTabbar = true;
           
        },
    }
</script>

<style lang="scss">
    .top{
        width: 100%;
        height: 50px;
        background-color: #1E1E1E;
        text-align: center;
        color: #fff;
        line-height: 50px;
        font-size: 18px;
        i{
            font-size: 30px;
        }
    }   
    .place{
        width: 30px;
        height: 54px;
        font-size: 15px;
        text-align: center;
        line-height: 54px;
        color: #666; 
        padding-left: 20px;     
    }
    .place-ic{  
       font-size: 8px;      
    }
    .searchBar{
        margin-top: 10px;
    }
    .cinema{
        width: 100%;
        margin-top: 15px;
        .shanghaiCinema{
            width: 100%;
            height: 100px;
            margin-top: 5px;
           
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
            .cinemaName{
                width: 100%;
                height: 30px;
                line-height: 30px;
                font-size: 16px;
                padding-left: 10px;
                margin: 5px auto;
            }
            .cinemaWhere{
                width: 100%;
                height: 20px;
                line-height: 20px;
                font-size: 12px;
                padding-left: 10px;
                margin: 2px auto;
                color: rgba(0, 0, 0, 0.7);
                .how-far{
                    font-size: 8px;
                    color: rgba(0, 0, 0, 0.6);
                    margin-left: 50px;
                    border: none;
                    display: inline;
                };
            }
            .activity{
                span{
                height:15px;
                font-size: 8px;
                padding: 2px;
                margin: 4px 8px;
                border-radius: 4px;
                display: inline-block; 
                border: 1px solid rgba(255, 174, 0, 0.5);
                color: rgba(255, 174, 0, 0.8) ;
                }
            }
            
        }
    }

</style>