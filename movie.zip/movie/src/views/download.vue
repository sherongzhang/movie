<template>
    <div>
        <div class="imgLogo">
            <img src="../assets/PandaLogo.jpg" alt="">
        </div>
        <van-button type="default" round color="rgb(0, 255, 0,0.5)" class="btnDownloadNow">立即下载</van-button>
    </div>
</template>

<script>
    export default {
         created(){
            this.$store.state.vanTabbar = false;
        },
       
        destroyed() {
            this.$store.state.vanTabbar = true;
           
        },
    }
</script>

<style lang="scss">
    .imgLogo{
        width: 100%;
        height: 364px;
        img{
            width: 100%;
            height: 364px;
        }
    }
    .btnDownloadNow{
        width: 50%;
        height: 35px;
        margin: 0 auto;
        line-height: 35px;
        display: block;
        
    }
</style>