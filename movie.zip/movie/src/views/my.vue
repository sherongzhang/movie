<template>
    <div>
        <div class="top"> 
            <van-row>
                <van-col span="4">
                    <i @click="$router.push({path:'/mv/hot'})"><van-icon name="arrow-left"/></i>   
                </van-col>
                <van-col span="16">黑袍电影</van-col>
                <van-col span="4"></van-col>
            </van-row>
        </div>
        <div class="login">
            <van-tabs v-model="active" color="#FFC300" line-width="180px">
                <van-tab title="美团账号登录"  to="/my/meituan" ></van-tab>
                <van-tab title="手机验证码登录" to="/my/phonelogin" ></van-tab>
            </van-tabs>
        </div>
         <router-view></router-view> 
    </div>
</template>

<script>
    export default {
        data() {
            return {
            active: 0
            };
        },
         created(){
            this.$store.state.vanTabbar = false;
        },
       
        destroyed() {
            this.$store.state.vanTabbar = true;
           
        },
    }
</script>

<style lang="scss">
    .top{
        width: 100%;
        height: 50px;
        background-color: #1E1E1E;
        text-align: center;
        color: #fff;
        line-height: 50px;
        font-size: 18px;
        i{
            font-size: 25px;
        }
    }
    .login{
        width: 100%;
        margin: 10px auto;
    }
</style>