<template>
    <div>   
        <div class="guide">
            <h2 class="animated fadeInDown">电影不是人生</h2>
            <h2 class="animated fadeInUp">但是那是条重回人生的路径</h2>
        </div>
        
        <router-view></router-view> 

    </div>
</template>

<script>
    export default {
        data(){
            return {
                num:2,
                cleardata:null //清除定时器
            }
        },
         created(){
             this.cleardata = setInterval(()=>{
                 if(this.num == 0){
                    this.$router.push("/guidePageLike");//推荐页面
                }else{
                    this.num--;
                }
             },1000)
            this.$store.state.vanTabbar = false;
        },
         beforeDestroy() { //销毁vue数据与方法。组件结束执行
            // 定时器属于浏览器对象，属于window。

            clearInterval(this.cleardata);
        },
        destroyed() {
            
           
        },
    }
</script>

<style lang="scss">
    
    .guide{
        height: 100%;
        position: absolute;
        top: 0px;
        left: 0px;
        width: 100%;
        background-image: url(../assets/skystar.jpeg);      
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center center;
        background-attachment: fixed;
        h2{
            width: 25px;
            color: rgb(255, 255, 255,0.6);
            &:nth-child(1){
                margin-left: 35%;
            }
            &:nth-child(2){
                margin-left: 60%;
            }
        }
    }
    
</style>