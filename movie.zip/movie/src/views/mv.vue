<template>
  <div id="app" >
    <van-sticky>
    <div class="topMv">
      <van-row>
        <van-col span="2"></van-col>
        <van-col span="20">黑袍电影</van-col>
        <!-- <van-col span="2"><i><van-icon name="ellipsis"/></i></van-col> -->
        <van-col span="2"></van-col>
      </van-row>
    </div>
    
    <div class="logo">
      <van-row>
          <van-col span="4"><img src="../assets/panda.jpg"> </van-col>
          <van-col span="14">        
              <p>黑袍</p>
              <p>在线选座，热门影讯，爱上看电影</p>
          </van-col>
          <van-col span="6"><van-button type="danger" size="small" to="/download" color="rgb(0, 255, 0,0.5)">立即下载</van-button></van-col>
      </van-row>
    </div>
    
    <div class="bar">
      <van-row>
          <van-col span="4" class="pl">
                  <p class="place_mv">地区</p>
                  <van-icon name="arrow-down" class="place-ic"/>
          </van-col>
          <van-col span="16">
              
              <van-tabs v-model="active" class="vanTab">
                  <van-tab title="正在热映" to="/mv/hot"></van-tab>
                  <van-tab title="即将上映" to="/mv/new"></van-tab>
              </van-tabs>
          </van-col>
          <van-col span="4">
            <router-link to="/search"> 
              <van-icon name="search" class="searchIcn"/>
            </router-link>      
          </van-col>
      </van-row>
    </div>
     </van-sticky> 
    <router-view></router-view> 
  </div>
</template>

<script>

export default {
  data() {
    return {
      active: 0
    };
  },
  methods: {    
  },

};
</script>

<style lang="scss">
    *{
      padding: 0;
      margin: 0;
    }
    
    .topMv{
        width: 100%;
        height: 50px;
        background-color: #1E1E1E;
        text-align: center;
        color: #fff;
        line-height: 50px;
        font-size: 18px;
        i{
            font-size: 20px;
        }
    }
    .logo{
      width: 100%;
      height: 64px;
      background-color: #fff;
      img{
        width: 60px;
        height: 44px;
        padding: 5px;
        
      }
      p{
        width: 100%;
        height: 22px;
        padding-left: 5px;
        &:nth-child(1){
          padding-top: 8px;
          font-size: 17px;
          color: #333;
        }
        &:nth-child(2){
          font-size: 12px;
          color: #999;
        }   
      }
      button{
        margin-top: 14px;
      }
    }
    .bar{
      width: 100%;
      height: 44px;
      padding-top: 5px;
      background-color: #fff;
    }
     
     .bar{
       .searchIcn{
         color: #1E1E1E;
         width: 40px;
         height: 45px;
         font-size: 25px;      
         line-height: 45px; 
         text-align: center;      
      }
      .pl{
          margin-top: 10px;
          text-align: center;
          .place_mv{
              width: 30px;
              height: 20px;
              font-size: 15px;
              color: #666;      
              display: inline-block;
          }
          .place-ic{
              width: 8px;
              height: 8px;
              font-size: 8px;
              padding: 1px;
          }
      }
     }
     
</style>