<template>
    <div>  
       <van-field
                        
         clearable          
         icon="question-o"
         placeholder="请输入手机号"
         bind:click-icon="onClickIcon"
       />             
        <van-field
        center
        clearable
        placeholder="请输入短信验证码"
        use-button-slot
        >
    <van-button slot="button" size="small" type="primary">发送验证码</van-button>
  </van-field>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>