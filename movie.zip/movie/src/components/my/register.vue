<template>
    <div>
        <div class="registerTop"> 
            <van-row>
                <van-col span="4">
                    <i @click="$router.go(-1)"><van-icon name="arrow-left"/></i>   
                </van-col>
                <van-col span="16">黑袍电影</van-col>
                <van-col span="4"></van-col>
            </van-row>
        </div> 
        <van-form>
            <van-field
                v-model="username"
                name="用户名"
                label="用户名"
                placeholder="用户名"
                :rules="[{ required: true, message: '请填写用户名' }]"
            />
            <van-field
                v-model="password"
                type="password"
                name="密码"
                label="密码"
                placeholder="密码"
                :rules="[{ required: true, message: '请填写密码' }]"
            />
            <van-field
                v-model="password2"
                type="password"
                name="验证密码"
                label="验证密码"
                placeholder="验证密码"
                :rules="[{ required: true, message: '请填写密码' }]"
            />
            <div style="margin: 16px;">
                <van-button round block type="info" native-type="submit" class="btn-register">
                提交
                </van-button>
            </div>
        </van-form>
    </div>
</template>

<script>
    export default {
         data() {
            return {
            username: '',
            password: '',
            password2:''
            };
        },
         methods: {
                
        },
          created(){
            this.$store.state.vanTabbar = false;
        },
       
        destroyed() {
            this.$store.state.vanTabbar = true;
           
        }
    }
</script>

<style lang="scss">
    .registerTop{
        width: 100%;
        height: 50px;
        background-color: #FE8C00;
        text-align: center;
        color: #fff;
        line-height: 50px;
        font-size: 18px;
        i{
            font-size: 25px;
        }
    }
    .btn-register{
        background-color: rgba(254, 140, 0, 0.7);
        border: none;
    }
</style>