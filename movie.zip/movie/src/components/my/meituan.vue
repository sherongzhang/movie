<template>
    <div>
        <van-cell-group>
            <van-field                 
                v-model="username"
                name="用户名"
                        
                placeholder="账户名/手机/Email"
                bind:click-icon="onClickIcon"
            />
            <van-field        
                type="password"
                placeholder="请输入您的密码"                    
            />
        </van-cell-group>
        <div class="btn">
             <van-button type="default" size="large" color="rgb(0, 255, 0,0.5)" class="loginBtn">登录</van-button>
        </div>
        
        <router-link to="/register" tag="div" class="register">立即注册</router-link>
        <!-- <router-link to="" tag="div" class="password">找回密码</router-link> -->
      
        
    </div>
</template>

<script>
    export default {
        data(){
            return{
                username: '',
                password: '',
            }
        },
        created(){
            this.$store.state.vanTabbar = false;
        },
       
        destroyed() {
            
           
        },
    }
</script>

<style lang="scss">
    
    .loginBtn{
        width: 94%;
        height: 28px;
        font-size: 15px;
        line-height: 28px;
        display: block;
        margin: 0 auto;
    }
    .register{     
        height: 20px;       
        width: 50%;
        font-size: 13px;
        color: #FE8C00;      
        display: inline-block;  
         box-sizing: border-box;
         margin-top: 10px;
    }
    .register{
        padding-left: 10px;
        
    }
     .password{
         text-align: right;
         padding-right: 20px;
        

     }
</style>