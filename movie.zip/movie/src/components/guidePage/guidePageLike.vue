<template>
    <div class="choice">
        <h3>选择你的爱好吧</h3>
        <div class="type" >
            <div v-for="(item, index) in lists" :key="index" @click="choiceOne($event,index)">{{item.type}}</div>               
        </div>
         <van-button plain type="" size="large" class="btn" to="/mv/hot">确定</van-button>
        
    </div>
</template>

<script>
    export default {
        data:function(){
            return{
                lists:[
                    {type:"科幻",id:1,isChoiceOne:true},
                    {type:"武侠",id:2,isChoiceOne:true},
                    {type:"奇幻",id:3,isChoiceOne:true},
                    {type:"动漫",id:4,isChoiceOne:true},
                    {type:"动作",id:5,isChoiceOne:true},
                    {type:"爱情",id:6,isChoiceOne:true},
                    {type:"都市",id:7,isChoiceOne:true},
                    {type:"喜剧",id:8,isChoiceOne:true},
                    {type:"恐怖",id:9,isChoiceOne:true},
                    {type:"冒险",id:10,isChoiceOne:true},
                    {type:"警匪",id:11,isChoiceOne:true},
                    {type:"战争",id:12,isChoiceOne:true},
                ],
                
            }
        },
        methods: {
            choiceOne(e,index){

                this.index = index
                this.data = this.lists

                console.log(this.data[index].isChoiceOne) //获取对象里的值

                if(this.data[index].isChoiceOne){
                    e.target.style.backgroundColor = "rgb(255,255,0,0.5)"
                   this.data[index].isChoiceOne = false ;
                }
                else{
                    e.target.style.backgroundColor = "rgb(255,255,255,0.4)"
                    this.data[index].isChoiceOne = true;
                }
            }
        },
          created(){
            this.$store.state.vanTabbar = false;
        },
       
        destroyed() {
            this.$store.state.vanTabbar = true;
           
        }
    }
</script>

<style lang="scss">
    $type-height-width:50px;
    
    .choice{
        height: 100%;
        position: absolute;
        top: 0px;
        left: 0px;
        width: 100%;
        background-color: rgb(148, 238, 229);
        background-image: url(../../assets/movie.jpg);      
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center center;
        background-attachment: fixed;

        .type{
            width: 90%;       
            margin: 0 auto;
            text-align: center;
            margin-top: 100px;
            margin-bottom: 50px;
            div{
                width: $type-height-width;
                height: $type-height-width;
                display: inline-block;
                margin: 20px;
                line-height:  $type-height-width;
                border-radius: 50%;
                background-color: rgb(255,255,255,0.4);
                
            }
        }

        h3{
            width: 100%;
            color: rgb(255, 255, 255,0.9);
            margin-top: 20px ;
            font-size: 30px;
            text-align: center;
        }
    }
    .btn{
        width: 90%;
        height: 40px;
        line-height: 40px;
        margin: 0 auto;
        display: block;
        color: cornflowerblue;
        border: none;
        background-color: rgb(255,255,255,0.4);
    }
</style>