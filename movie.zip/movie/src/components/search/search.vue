<template>
    <div>
        <div class="top"> 
            <van-row>
                <van-col span="3">
                    <i @click="$router.push({path:'/mv/hot'})"><van-icon name="arrow-left"/></i>   
                </van-col>
                <van-col span="18">黑袍电影</van-col>
                <van-col span="3">
                    <i @click="$router.push({path:'/my/meituan'})"><van-icon name="user-o" /></i>
                 </van-col>
            </van-row>
        </div>
        <div class="searchBox">
            <van-row>
                <van-col span="21"><van-search placeholder="搜电影"/></van-col>
                <van-col span="3"><span @click="$router.push({path:'/mv/hot'})">取消</span></van-col>
            </van-row>
        </div>
        <div class="hot_search">
            <p>热门搜索</p>
            <ul>
                <li>叶问4</li>
                <li>北平会馆</li>
                <li>印度奇游</li>
                <li>大红包</li>
                <li>加勒比海盗5:死无对证</li>
            </ul>
        </div>
        
    </div>
    
</template>

<script>
     export default {
        
        created(){
            this.$store.state.vanTabbar = false;
        },
       
        destroyed() {
            this.$store.state.vanTabbar = true;
           
        },
    }
</script>

<style lang="scss">
    .top{
        width: 100%;
        height: 50px;
        background-color: #1E1E1E;
        text-align: center;
        color: #fff;
        line-height: 50px;
        font-size: 18px;
        i{
            font-size: 30px;
            line-height: 50px;
        }
    }
    .searchBox{
        
        span{
            height: 50px;
            text-align: center;
            line-height: 50px;
            color:  rgb(0, 255, 0,0.5);
        }
    }
    .hot_search{
        width: 100%;
        p{
            font-size: 16px;
            margin: 10px;
            color: firebrick;
        }
        ul{
            width: 100%;
            li{
                height: 25px;
                line-height: 25px;
                
                border-bottom: 1px solid #999;
                
                margin: 10px 15px 10px 15px;
                color: rgb(0, 0, 0,0.5);
                font-size: 14px;
               
            }
        }
    }
</style>