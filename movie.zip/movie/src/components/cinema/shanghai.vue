<template>
    <div>
        <div class="top"> 
            <van-row>
                <van-col span="2">
                    <i @click="$router.go(-1)"><van-icon name="arrow-left"/></i>   
                </van-col>
                <van-col span="22">UA电影城（上海梅龙镇广场店）</van-col>
                
            </van-row>
        </div>
        <div class="cinema-shanghai">
           <p class="cinema_title">黑袍电影 > UA电影城（上海梅龙镇广场店）</p>
           <p class="cinema_name">UA电影城（上海梅龙镇广场店）</p>
           <p class="cinema_where">静安区南京西路1038号梅龙镇广场10楼（近江宁路)</p>
        </div>

        <div class="tuan-list">
            <p class="tuan-title">影院超值套餐</p>
            <div class="tuan-item">
              <img src="../../assets/food.jpg" alt="">
              <div class="tuan-item-title">
                  <span class="two">双人</span> 12oz生姜茶*1+12oz百香果茶*1+爆米花（65g）*1
                  <p class="pay">￥50</p>
                  <van-button type="danger" size="mini" class="shop" to="/pay">去购买</van-button>
              </div>
            </div>
            <div class="tuan-item">
              <img src="../../assets/food.jpg" alt="">
              <div class="tuan-item-title">
                  <span class="two">双人</span> 12oz生姜茶*1+12oz百香果茶*1+爆米花（65g）*1
                  <p class="pay">￥50</p>
                  <van-button type="danger" size="mini" class="shop" to="/pay">去购买</van-button>
              </div>
            </div>
            <div class="tuan-item">
              <img src="../../assets/food.jpg" alt="">
              <div class="tuan-item-title">
                  <span class="two">双人</span> 12oz生姜茶*1+12oz百香果茶*1+爆米花（65g）*1
                  <p class="pay">￥50</p>
                  <van-button type="danger" size="mini" class="shop" to="/pay">去购买</van-button>
              </div>
            </div>
            <div class="tuan-item">
              <img src="../../assets/food.jpg" alt="">
              <div class="tuan-item-title">
                  <span class="two">双人</span> 12oz生姜茶*1+12oz百香果茶*1+爆米花（65g）*1
                  <p class="pay">￥50</p>
                  <van-button type="danger" size="mini" class="shop" to="/pay">去购买</van-button>
              </div>
            </div>
            <div class="tuan-item">
              <img src="../../assets/food.jpg" alt="">
              <div class="tuan-item-title">
                  <span class="two">双人</span> 12oz生姜茶*1+12oz百香果茶*1+爆米花（65g）*1
                  <p class="pay">￥50</p>
                  <van-button type="danger" size="mini" class="shop" to="/pay">去购买</van-button>
              </div>
            </div>
            <h2 class="eat">不如一起品味电影</h2>
        </div>
        
    </div>
</template>

<script>
    export default {
          created(){
            this.$store.state.vanTabbar = false;
        },
       
        destroyed() {
            this.$store.state.vanTabbar = true;
           
        },
    }
</script>

<style lang="scss">
    .top{
        width: 100%;
        height: 50px;
        background-color: #1E1E1E;
        text-align: center;
        color: #fff;
        line-height: 50px;
        font-size: 18px;
        i{
            font-size: 25px;
        }
    }
    .cinema-shanghai{
      width: 95%;
      height: 110px;
      margin: 0 auto;
      background-color: cornsilk;
      padding-top: 5px;
      .cinema_title{
        color: #777;
        font-size: 14px;
        margin: 0;
      }
      .cinema_name{
        color: #333;
        font-size: 17px;
        font-weight: bold;
      }
      .cinema_where{
        color: #999;
        font-size: 13px;
      }
    }
    .tuan-list{
      width: 100%;
     
      padding: 10px;
      .tuan-title{
        margin: 0;
        color: #777;
        font-size: 15px;
      }
      .tuan-item{
        margin-top: 10px;
        padding: 13px 0px;
        height: 92px;
        border-bottom: 1px solid rgb(223, 217, 217);
        img{
          width: 92px;
          height: 92px;
        }
        .tuan-item-title{
          width: 70%;
          height: 92px;  
          font-size: 14px;
          float: right;
          .two{
            display: inline-block;
            width: 28px;
            height: 15px;
            font-size: 10px;
            background-color: #f90;
            text-align: center;
            line-height: 15px;
            color: #fff;
          }
          .pay{
            width: 40px;
            margin: 5px 10px;
            font-size: 17px;
            color: #f03d37;
          }
          .shop{
            float: right;
            margin-right: 20px;
            width: 52px;
            height: 27px;
            padding: 0px 8px;
          }
        }
        
        }
      }
      .eat{
          width: 90%;
          text-align: center;
          font-weight: normal;
          color: #999;
    }
</style>