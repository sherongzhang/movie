<template>
    <!-- 支付页 -->
    <div>
        <div class="top"> 
            <van-row>
                <van-col span="2">
                    <i @click="$router.go(-1)"><van-icon name="arrow-left"/></i>   
                </van-col>
                <van-col span="20">确认订单</van-col>
                <van-col span="2"></van-col>
            </van-row>      
        </div>
        <div class="pay-item">
                <img src="../../assets/food.jpg" alt="">
                <div class="pay-item-title">
                    <span class="two">单人</span> 12oz生姜茶*1+12oz百香果茶*1+爆米花（65g）*1
                    <p class="pay">50元</p><del>80元</del> 
                </div>
        </div>
        <div class="details">
            <h4>套餐详情</h4>
            <div class="details-thing">
                <span>生姜茶</span>
                <span>1杯</span>
            </div>
            <div class="details-thing">
                <span>百香果茶</span>
                <span>1杯</span>
            </div>
            <div class="details-thing">
                <span>爆米花</span>
                <span>1桶</span>
            </div>
        </div>
        <div class="details-num">
            <span>数量</span> 
              <div slot="tags" class="pay-num">  
                    <van-tag plain @click="lists.num <=1?1:lists.num--" class="add-reduce">-</van-tag>
                    <input type="text" v-model="lists.num" class="num" >
                    <van-tag plain @click="lists.num++" class="add-reduce">+</van-tag>
             </div>
        </div>
        <div class="msg">
            <h4>提示信息</h4>
            <p class="msg-time">使用时间：请在影城卖品部营业时间兑换。</p>
        </div>
        <div class="pay-for">
            <div class="pay-for-num"><span class="add">小计</span><span class="pay-icn">￥</span><span class="pay-num">{{lists.num*50}}</span></div>
           
            <van-button type="primary" size="large" class="confirm" >立即支付</van-button>
        </div>
    </div>
</template>

<script>
    export default {
        data:function(){
            return {
                lists:{
                    num:1
                }
            }
        },
        created(){
            this.$store.state.vanTabbar = false;
        },
       
        destroyed() {
            this.$store.state.vanTabbar = true;
           
        },
    }
</script>

<style lang="scss">
     .top{
        width: 100%;
        height: 50px;
        background-color: #1E1E1E;
        text-align: center;
        color: #fff;
        line-height: 50px;
        font-size: 18px;
        i{
            font-size: 25px;
        }
    }
    .pay-item{
        margin-top: 10px;
        padding: 13px 0px;
        height: 92px;
        background-color: #fff;
        border-bottom: 1px solid rgb(223, 217, 217);
        img{
          width: 92px;
          height: 92px;
        }
        .pay-item-title{
          width: 70%;
          height: 92px;  
          font-size: 14px;
          float: right;
          .two{
            display: inline-block;
            width: 28px;
            height: 15px;
            font-size: 10px;
            background-color: #f90;
            text-align: center;
            line-height: 15px;
            color: #fff;
          }
          .pay{
            margin: 10px 0px 0px 0px;
            font-size: 20px;
            color: #f03d37;
          }
          del{
              position: absolute;
              margin-left: 5px;
              color: #777;
          }
        }      
    }
    .details{
        width: 100%;     
        margin-top: 20px;
        
        background-color: rgb(0, 0, 0,0.05);
        h4{
            color: #333;
            padding-top: 10px;
            padding-left: 5px;
            margin:0px 0px 5px 0px;
        }
        .details-thing{
            width: 100%;
            height: 40px;
            line-height: 40px;
            margin-top: 10px;
            
            span{
                font-size: 14px;
                color: #999;
                &:nth-child(1){
                    padding-left: 10px;
                }
                &:nth-child(2){
                    float: right;
                    padding-right: 10px;
                }
            }
        }
    }  
    .details-num{
        width: 100%;
        height: 60px;
        margin-top: 20px;
        background-color: rgb(100, 149, 237,0.05);
        span{
            display: inline-block;
            margin-top: 18px;
            margin-left: 20px;
        }
        .pay-num{   
            float: right;
        }
        .add-reduce{
            width: 30px;
            height: 34px;
            padding: 0;
            font-size: 20px;
            display: inline-block;
            text-align: center;
            line-height: 34px;
            margin: 10px;
            font-weight: bold;
        }
        .num{
            width: 50px;
            height: 30px;
            padding: 0;
            border: 1px solid #DDD8CE;
            text-align: center;
        }
    }
    .msg{
        width: 100%;
        margin: 15px auto;
        background-color: rgba(111, 0, 139, 0.05);
         h4{
            padding: 5px;
            color: #333;
            margin:0px 0px 5px 0px;
          }
        .msg-time{
            font-size: 14px;
            color: #999;
            padding: 10px;
        }
    }
    .pay-for{
        width: 90%;
        height: 120px;
        margin: 20px auto;
        background-color: rgba(184, 135, 11, 0.05);
        
        .pay-for-num{
            span{
               &:nth-child(1){
                font-size: 14px;
                padding-left: 250px;
                padding-right: 10px;
                color: #333;
                font-weight: bold;
            }
            &:nth-child(2){
                font-size: 12px;
                padding-right: 5px;
                color: #33c1af;
            }
            &:nth-child(3){
                font-size: 30px;
                color: #33c1af
            } 
            }
            
        }
        .confirm{
            width: 90%;
            height: 40px;
            margin: 15px auto;
            text-align: center;
            display: block;
            background-color: #f80;
            border: none;
            padding: 0;
            line-height: 40px;
            font-size: 18px;
        }
    }
</style>