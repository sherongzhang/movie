<template>
    <div>
        <div>
            <p class="panda_title">黑袍咨询 > 咨询正文</p>
            <h1 class="beipinghuiguan">《北平会馆》死亡名册泄漏，再现京城风波最盛的空前真实恐怖！</h1>
            <p class="content">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;说起《死亡笔记》这部作品，大家都不陌生，这部堪称斗智巅峰的动漫，也是第一部在中国网络上掀起波澜的作品。剧情精妙烧
                脑、值得玩味的细节百出，据传名字被写在这个本子上的人就会真的死去。带有复仇、诅咒意味的死亡笔记真的存在于世吗？由李路执导，程中豪监制，阮景
                东编剧，宋海江、戈俊、李怀宁、张帆担任出品人，吴大可、朱梓瑜、刘亦彤、宋泽平、李晨、田新华、任喜法、黄紫轩 、联合制片，、上淇、杜东、彭朝辉、
                段志峰、周岳龙等主演的凶宅系列电影《北城会馆》即将答案揭晓！
                </p>
                <img src="../../assets/beiping.jpg" alt="" class="poster">
                <strong>死亡名册重现于世 诡谲离奇事件频现会馆！</strong>
                <p class="content">影片以京城四大凶宅之最凶宅作为故事原型，讲述了民国时期，北平会馆内明争暗斗，引发了一系列连环凶杀案，冤魂四起之下，传说有一本未卜先知的
                    死亡名册，一旦有人的名字出现在上面，就会成为死神掠杀的下一个目标，而这一死亡现象随着死亡名册的消失暂告一断落。不曾想，随着老东家遇害，
                    看守会馆的王麻子的失踪，月黑风高之夜，阴郁笼罩会馆，新的死亡传说诞生，“二胡声响，必有怪事发生”的夺命事件惊现于世，闯入会馆之人源源不断
                    地离奇消失，不见踪影。诡异现象的广泛流传，引起周围居民的恐慌，血腥命案不断的蹊晓也引起了警局高度重视，遂决定查清真相，委派法国留学回来
                    的法医介入。听闻会馆死亡传言的小说家为了找寻创作灵感特意来到此地与简宁不期而遇。原本打算携手查案的两人随着逃婚出来不得已躲进会馆的宋佩
                    佩的介入，暗生嫌隙。人心不齐也让查明真相的道路阻碍重重，长居于此的戏曲名角李天沫更是充满着古怪，一直暗示不请自来的三个人赶快远离会馆。
                    然而伴随着各种诡异接踵而至之后，四个人不得不统一战线走上了破解会馆死亡传说的惊魂谜案中！在会馆某一处，消失多年的死亡笔记随着死去十年的
                    王麻子魂魄归来而再次浮现，让人在惊慌失措与虚惊一场中冷热交替，随着查案过程中不断出现的变动，此起彼伏的二胡声将死神的魔抓悄悄伸向四个人，
                    真正的恐怖才刚刚开始..…
                </p>
            <p class="aboutMv">相关电影</p>
        </div>
        <div class="nowIsOnline">
                <div class="now_mv" @click="$router.push({path:'/newDetailsPage'})">
                    <div class="mv_img">
                        <img src="../../assets/北平会馆.jpg" alt="">
                    </div>
                    <span class="mv_name">
                        北平会馆
                    </span>
                    <span class="mv_ac">
                        主演: 吴大可,朱梓瑜,刘亦彤
                    </span>
                    <span class="date">
                        2020-04-04上映
                    </span>
                </div>
            </div>
    </div>
</template>

<script>
    export default {
         created(){
            this.$store.state.vanTabbar = false;
        },
       
        destroyed() {
            this.$store.state.vanTabbar = true;
           
        },
    }
</script>

<style lang="scss">
    .aboutMv{
        font-size: 14px;
        width: 100px;
        height: 20px;
        line-height: 20px;
        text-align: center;
        color: #666;
        margin: 5px;
    }
    .panda_title{
        font-size: 14px;
        width: 150px;
        height: 20px;
        line-height: 20px;
        text-align: center;
        color: #666;
        margin: 5px;
    }
    .beipinghuiguan{
        font-size: 24px;
        text-align: center;
        margin: 10px;
    }
    .content{
        width: 90%;
        font-size: 16px;
        color: #222;
        margin: 0 auto;
        line-height: 1.8;
    }
    .poster{
        width: 90%;
        margin: 5px auto;
        display: block;
    }
    strong{
        width: 90%;
        margin: 10px auto;
        display: block;
        font-size: 16px;
        
    }
    .nowIsOnline{
        width: 100%;
        
        margin-top: 10px;
        margin-bottom: 30px;
        .now_mv{
            width: 100%;
            height: 115px;
            position: relative;
            background-color: rgb(255,255,0,0.2);
            margin-top: 20px;
            .mv_img{
                width: 85px;
                height: 115px;
                margin-left: 20px;
                display: inline-block;
                img{
                    width: 85px;
                    height: 115px;
                }
            }
            span{
                position: absolute;
                left: 130px; 
            }
           .mv_name{
                top: 10px;
                font-size: 17px;
                font-weight: bold;
            }
            .mv_ac{
                top: 45px;
                font-size: 13px;
                color: #999;
            }
            .date{
                top: 75px;
                font-size: 13px;
                color: #999;
            } 
        }
        
    }
</style>