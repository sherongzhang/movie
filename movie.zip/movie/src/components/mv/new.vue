<template>
    <div>
        <div class="mv">

            <p class="title">近期热映的电影</p>

            <div class="swiper-container hot-mv">
                <div class="swiper-wrapper hot-mv-bg" >
                    <div class="swiper-slide hot-mv-img">
                        <img src="../../assets/mv.png" alt="">
                        <p>小公主艾薇拉...</p>
                    </div>
                   <div class="swiper-slide hot-mv-img">
                        <img src="../../assets/大红包.jpg" alt="">
                        <p>大红包</p>
                    </div>
                   <div class="swiper-slide hot-mv-img">
                        <img src="../../assets/北平会馆.jpg" alt="">
                        <p>北平会馆</p>
                    </div>
                   <div class="swiper-slide hot-mv-img">
                        <img src="../../assets/印度奇游.jpg" alt="">
                        <p>印度奇游</p>
                    </div>
                   <div class="swiper-slide hot-mv-img">
                        <img src="../../assets/mv.png" alt="">
                        <p>小公主艾薇拉...</p>
                    </div>
                   <div class="swiper-slide hot-mv-img">
                        <img src="../../assets/大红包.jpg" alt="">
                        <p>大红包</p>
                    </div>
                   <div class="swiper-slide hot-mv-img">
                        <img src="../../assets/北平会馆.jpg" alt="">
                        <p>北平会馆</p>
                    </div>
                   <div class="swiper-slide hot-mv-img">
                        <img src="../../assets/印度奇游.jpg" alt="">
                        <p>印度奇游</p>
                    </div>
                </div>

            </div>
            <p class="whenOnline">4月4日上映</p>
            <div class="nowIsOnline">
                <div class="now_mv" @click="$router.push({path:'/newDetailsPage'})">
                    <div class="mv_img">
                        <img src="../../assets/北平会馆.jpg" alt="">
                    </div>
                    <span class="mv_name">
                        北平会馆
                    </span>
                    <span class="mv_ac">
                        主演: 吴大可,朱梓瑜,刘亦彤
                    </span>
                    <span class="date">
                        2020-04-04上映
                    </span>
                </div>
                <div class="now_mv">
                    <div class="mv_img">
                        <img src="../../assets/北平会馆.jpg" alt="">
                    </div>
                    <span class="mv_name">
                        北平会馆
                    </span>
                    <span class="mv_ac">
                        主演: 吴大可,朱梓瑜,刘亦彤
                    </span>
                    <span class="date">
                        2020-04-04上映
                    </span>
                </div>
                <div class="now_mv">
                    <div class="mv_img">
                        <img src="../../assets/北平会馆.jpg" alt="">
                    </div>
                    <span class="mv_name">
                        北平会馆
                    </span>
                    <span class="mv_ac">
                        主演: 吴大可,朱梓瑜,刘亦彤
                    </span>
                    <span class="date">
                        2020-04-04上映
                    </span>
                </div>
            </div>
            
        </div>
       
    </div>
</template>

<script>
    import Swiper from "swiper";
    export default {
        data() {
            return {
            active: 1
            };
        },
        mounted(){
              new Swiper('.swiper-container', {
                slidesPerView: 4,
                freeMode: true,
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                },
            });
        }
    }
</script>

<style lang="scss">
   
    .title{
            width: 90%;
            
            font-size: 14px;
            color: #333;
            margin: 15px 0px 0px 5px;
        }
    .hot-mv{
        .hot-mv-bg{
            .hot-mv-img{
                    width: 85px;
                    height: 160px;
                img{
                    width: 85px;
                    height: 115px;
                }
                p{
                    position: absolute;
                    bottom: 0px;
                    width: 90px;
                    font-size: 13px;
                    font-weight: bold;
                    color: #333;
                }
            }
        }
    }
    .new{
        width: 100%;
        p{
            width: 100%;
            font-size: 14px;
            color: #333;
            margin: 14px;
        }
    }
    .whenOnline{
        width: 100px;
        height: 25px;
        line-height: 25px;
        font-size: 14px;
        color: #666;
        margin-top: 10px;
        margin-left: 20px;
    }
    .nowIsOnline{
        width: 100%;
        height: 500px;
        margin-top: 10px;
        
        .now_mv{
            width: 100%;
            height: 115px;
            position: relative;
            background-color: rgb(255,255,0,0.2);
            margin-top: 20px;
            .mv_img{
                width: 85px;
                height: 115px;
                margin-left: 20px;
                display: inline-block;
                img{
                    width: 85px;
                    height: 115px;
                }
            }
            span{
                position: absolute;
                left: 130px; 
            }
           .mv_name{
                top: 10px;
                font-size: 17px;
                font-weight: bold;
            }
            .mv_ac{
                top: 45px;
                font-size: 13px;
                color: #999;
            }
            .date{
                top: 75px;
                font-size: 13px;
                color: #999;
            } 
        }
        
    }



//公公样式
.swiper-container {
      width: 100%;
      height: 100%;
    }
    .swiper-slide {
    
      font-size: 18px;
      

      /* Center slide text vertically */
      display: -webkit-box;
      display: -ms-flexbox;
      display: -webkit-flex;
      display: flex;
      -webkit-box-pack: center;
      -ms-flex-pack: center;
      -webkit-justify-content: center;
      justify-content: center;
      -webkit-box-align: center;
      -ms-flex-align: center;
      -webkit-align-items: center;
      align-items: center;
    }

    
</style>