<template>
    <div id="appMv">
        <div class="beiping">
             <p class="beiping_title" @click="$router.push({path:'/mv/new'})">黑袍咨询 > 北平会馆</p>
            <div class="beiping_mv">
                <img src="../../assets/北平会馆.jpg" alt="">
                <p class="mv_name">北平会馆</p>
                <p class="mv_name_en">BEIJING GUILD HALL</p>
                <p class="mv_a"></p>
                <p class="mv_tpye">惊悚 / 恐怖 / 悬疑</p>
                <p class="time">2020-04-04大陆上映 / 98分钟</p>
                <p></p>
                <van-button plain hairline type="primary" class="want" to="/mv/new">看过</van-button>
                <van-button plain hairline type="info" class="wacthed" @click="want($event)">想看</van-button>
                <div class="howMany">
                    <h5>实时口碑</h5>
                    <div class="many"><span>{{lists.num}}</span><span>人想看</span></div>
                    <span class="num_one">同期想看人数第一</span>
                </div>
                <div class="introduction">
                    <h5>简介</h5>
                    <span>月黑风高，女鬼出没！京城四大凶宅之一的北平会馆内，邪灵魅影飘忽不定，诡秘的二胡声一响，必有人魂飞魄散，尖叫毙命！连环死亡名
                    册引发阵阵恐慌，每位在会馆横死的人，都将被记录在册。躲在暗处的难解之谜、无法破除的死亡诅咒、如厉鬼磨牙吮血的骇人夺命二胡声、
                    不翼而飞的尸体、光怪陆离的超自然现象死亡、令人凄神寒骨的人偶，让整个会馆氤氲着死亡气息。海归女法医神秘出现联手恐怖作家为解
                    开迷局，不顾生死闯入会馆，却让事情变得更加扑朔迷离。北平会馆内毛骨悚然的二胡声从未停歇，怪诞诡奇的死亡依旧在继续...</span>         
                </div>

                
            </div>
        </div>
    </div>
</template>

<script>
import Swiper from "swiper";
    export default {
        data:function(){
            return {
                lists:{
                    num:15063,
                    add:true
                }
            }
        },
        methods:{
            want(e){
                if(this.lists.add){
                    this.lists.num += 1;
                    this.lists.add = false;
                    e.target.style.backgroundColor = "rgb(255,255,255,0.1)"
                }
                else{
                     this.lists.num -= 1;
                     this.lists.add = true;
                     e.target.style.backgroundColor = "rgb(255, 255, 255,0.35)"
                }
                console.log(this.lists.add)
            }
        },
        mounted(){
              new Swiper('.swiper-container', {
                slidesPerView: 4,
                freeMode: true,
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                },
            });
        },
         created(){
            this.$store.state.vanTabbar = false;
        },
       
        destroyed() {
            this.$store.state.vanTabbar = true;
           
        },
    }
</script>

<style lang="scss">
    .beiping{
        width: 100%;
        height: 900px;
        padding-top: 20px;
        background-color: #2B2943;
        
    }
    .beiping_title{
        font-size: 14px;
        width: 150px;
        height: 20px;
        line-height: 20px;
        text-align: center;
        color: rgb(255, 255, 255,0.8);
        margin-left: 10px;  
        margin-bottom: 10px;  
    }
    .beiping_mv{
        width: 90%;
        height: 138px;
        margin: 10px auto;
        position: relative;
        img{
            width: 100px;
            height: 138px;
        }
        p{
            position: absolute;
            color: rgb(255, 255, 255,0.7);
            left: 120px;
        }
        .mv_name{
            top: 0;
            font-size: 20px;
            font-weight:bold;          
        }
        .mv_name_en{
            top: 30px;
            font-size: 12px;
        }
        .mv_tpye{
            top: 50px;
            font-size: 12px;
        }
        .time{
            top: 70px;
            font-size: 12px;
        }
        .want{
            width: 122px;
            height:30px;
            border: none;
            line-height: 30px;
            position: absolute;
            top: 100px;
            left: 110px;
            color: rgb(255, 255, 255,0.8);
             background-color: rgb(255, 255, 255,0.35);
        }  
        .wacthed{
            width: 122px;
            height:30px;
            border: none;
            line-height: 30px;
            position: absolute;
            top: 100px;
            left: 250px;
             color: rgb(255, 255, 255,0.8);
            background-color: rgb(255, 255, 255,0.35);
        } 
    }
    .howMany{
        width: 95%;
        height: 150px;
        margin: 30px auto;
        padding: 5px;
        background-color: rgb(0, 0, 0,0.2);
        h5{
            color: rgb(255, 255, 255,0.8);
            padding-left: 15px;
            margin-bottom: 10px;
            
        }
        .many{
            width: 100%;
            height: 80px;
            text-align: center;
            line-height: 80px;
            span{
                
                
                &:nth-child(1){
                    color: #FFBB28;
                    font-size: 28px;
                }
                &:nth-child(2){
                    color: #fff;
                    font-size: 24px;
                 
                }
            }
        }
        .num_one{
            font-size: 12px;
            color: #ffe4a2;
            width: 100%;
            height: 25px;
            margin: 0;
            display: block;
            line-height: 25px;
            border-top:1px solid rgb(255, 255, 255,0.05);
        }
    }
    .introduction{
        width: 90%;
        height: 300px;
        margin: 0 auto;
        font-size: 15px;
        color: #fff;
        span{
            width: 100%;
            text-align: justify;
            line-height: 1.8;
            letter-spacing:3pt;
        }
    }
    
</style>