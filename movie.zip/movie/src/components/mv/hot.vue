<template>
    <div id="app">
        <div class="man">

            <p class="title">热门影人</p>

            <div class="swiper-container hot-man">
                <div class="swiper-wrapper hot-man-bg" >
                    <div class="swiper-slide hot-man-img">
                        <img src="../../assets/zzd.jpg" alt="">
                        <p>甄子丹</p>
                    </div>
                   <div class="swiper-slide hot-man-img">
                        <img src="../../assets/chenglong.jpg" alt="">
                        <p>成龙</p>
                    </div>
                   <div class="swiper-slide hot-man-img">
                        <img src="../../assets/huxia.jpg" alt="">
                        <p>胡夏</p>
                    </div>
                   <div class="swiper-slide hot-man-img">
                        <img src="../../assets/yueyunpeng.jpg" alt="">
                        <p>岳云鹏</p>
                    </div>
                   <div class="swiper-slide hot-man-img">
                        <img src="../../assets/zzd.jpg" alt="">
                        <p>甄子丹</p>
                    </div>
                   <div class="swiper-slide hot-man-img">
                        <img src="../../assets/chenglong.jpg" alt="">
                        <p>成龙</p>
                    </div>
                   <div class="swiper-slide hot-man-img">
                        <img src="../../assets/huxia.jpg" alt="">
                        <p>胡夏</p>
                    </div>
                   <div class="swiper-slide hot-man-img">
                        <img src="../../assets/yueyunpeng.jpg" alt="">
                        <p>岳云鹏</p>
                    </div>
                </div>

            </div>
        </div>
        <div class="new">
            <p>娱乐热点</p>
            <p @click="$router.push({path:'/hotDetailsPage'})">1. 《北平会馆》死亡名册泄漏，再现京城风波最盛的空前真实恐怖！</p>
            <p @click="$router.push({path:'/hotDetailsPage'})">2. 《北平会馆》死亡名册泄漏，再现京城风波最盛的空前真实恐怖！</p>
            <p @click="$router.push({path:'/hotDetailsPage'})">3. 《北平会馆》死亡名册泄漏，再现京城风波最盛的空前真实恐怖！</p>
            <p @click="$router.push({path:'/hotDetailsPage'})">4. 《北平会馆》死亡名册泄漏，再现京城风波最盛的空前真实恐怖！</p>
            <p @click="$router.push({path:'/hotDetailsPage'})">5. 《北平会馆》死亡名册泄漏，再现京城风波最盛的空前真实恐怖！</p>
            <p @click="$router.push({path:'/hotDetailsPage'})">6. 《北平会馆》死亡名册泄漏，再现京城风波最盛的空前真实恐怖！</p>
            <p @click="$router.push({path:'/hotDetailsPage'})">7. 《北平会馆》死亡名册泄漏，再现京城风波最盛的空前真实恐怖！</p>
            <p @click="$router.push({path:'/hotDetailsPage'})">8. 《北平会馆》死亡名册泄漏，再现京城风波最盛的空前真实恐怖！</p>
            <p @click="$router.push({path:'/hotDetailsPage'})">9. 《北平会馆》死亡名册泄漏，再现京城风波最盛的空前真实恐怖！</p>
            <p @click="$router.push({path:'/hotDetailsPage'})">10. 《北平会馆》死亡名册泄漏，再现京城风波最盛的空前真实恐怖！</p>
            <p @click="$router.push({path:'/hotDetailsPage'})">11. 《北平会馆》死亡名册泄漏，再现京城风波最盛的空前真实恐怖！</p>
            <p @click="$router.push({path:'/hotDetailsPage'})">12. 《北平会馆》死亡名册泄漏，再现京城风波最盛的空前真实恐怖！</p>
            
        </div>
    </div>
</template>

<script>
    import Swiper from "swiper";
    export default {
        data() {
            return {
            active: 0
            };
        },
        mounted(){
              new Swiper('.swiper-container', {
                slidesPerView: 4,
                freeMode: true,
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                },
            });
        }
    }
</script>

<style lang="scss">
   
    .title{
            width: 90%;
            
            font-size: 14px;
            color: #333;
            margin: 15px 0px 0px 5px;
        }
    .hot-man{
        .hot-man-bg{
            .hot-man-img{
                    width: 85px;
                    height: 160px;
                img{
                    width: 85px;
                    height: 115px;
                }
                p{
                    position: absolute;
                    bottom: 0px;
                    width: 85px;
                    font-size: 13px;
                    font-weight: bold;
                    color: #333;
                }
            }
        }
    }
    .new{
        width: 100%;
        p{  
            width: 90%;
            height: 20px;
            font-size: 14px;
            color: #333;
            margin: 14px;
            white-space: nowrap;
            overflow: hidden;  
            text-overflow: ellipsis;
        }
    }
//公公样式
.swiper-container {
      width: 100%;
      height: 100%;
    }
    .swiper-slide {
      text-align: center;
      font-size: 18px;
    

      /* Center slide text vertically */
      display: -webkit-box;
      display: -ms-flexbox;
      display: -webkit-flex;
      display: flex;
      -webkit-box-pack: center;
      -ms-flex-pack: center;
      -webkit-justify-content: center;
      justify-content: center;
      -webkit-box-align: center;
      -ms-flex-align: center;
      -webkit-align-items: center;
      align-items: center;
    }

    
</style>