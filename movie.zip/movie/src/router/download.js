export default {
    path:"/download",
    name:"下载",
    component:()=>import("../views/download.vue")
}