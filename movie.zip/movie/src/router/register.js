export default {
    path:"/register",
    name:"立即注册",
    component:()=>import("../components/my/register.vue")
}