export default {
    path:"/my",
    name:"我的",
    component:()=>import("../views/my.vue"),
    children:[
        {
            path:"meituan",
            name:"美团登录",
            component:()=>import("../components/my/meituan.vue")
        },
        {
            path:"phonelogin",
            name:"手机验证码登录",
            component:()=>import("../components/my/phonelogin.vue")
        },
       
    ]
}