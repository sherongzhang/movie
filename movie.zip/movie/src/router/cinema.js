export default {
    path:"/cinema",
    name:"影院",
    component:()=>import("../views/cinema.vue")
}