export default {
    path:"/shanghai",
    name:"上海",
    component:()=>import("../components/cinema/shanghai.vue")
}