export default {
    path:"/pay",
    name:"支付",
    component:()=>import("../components/cinema/pay.vue")
}