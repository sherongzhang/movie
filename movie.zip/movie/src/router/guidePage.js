export default {
    path:"/guidePage",
    name:"引导页",
    component:()=>import("../views/guidePage.vue"),
    
}