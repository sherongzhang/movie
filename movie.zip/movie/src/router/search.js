export default {
    path:"/search",
    name:"搜索",
    component:()=>import("../components/search/search.vue")
}