//电影首页
export default{
    path:"/mv",
    name:"电影",
    component:()=>import("../views/mv.vue"),
    children:[
        {
            path:"hot",
            name:"热门电影",
            component:()=>import("../components/mv/hot.vue")
        },
        {
            path:"new",
            name:"即将上映",
            component:()=>import("../components/mv/new.vue")
        },
        {
            path:"place",
            name:"地区",
            component:()=>import("../components/mv/place.vue")
        },
        
    ]
}