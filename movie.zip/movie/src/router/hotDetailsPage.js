export default {
    path:"/hotDetailsPage",
    name:"北平会馆新闻",
    component:()=>import("../components/mv/hotDetailsPage.vue")
}