export default {
    path:"/guidePageLike",
    name:"性别",
    component:()=>import("../components/guidePage/guidePageLike.vue"),
}