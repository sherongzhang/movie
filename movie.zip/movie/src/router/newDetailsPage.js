export default {
    path:"/newDetailsPage",
    name:"北平会馆详情",
    component:()=>import("../components/mv/newDetailsPage.vue")
}