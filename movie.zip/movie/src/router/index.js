import Vue from 'vue'
import VueRouter from 'vue-router'

import mv from './mv'
import search from './search'
import cinema from './cinema'
import my from './my'
import download from './download'
import guidePage from './guidePage'
import guidePageLike from './guidePageLike'
import hotDetailsPage from './hotDetailsPage'
import newDetailsPage from './newDetailsPage'
import shanghai from './shanghai'
import pay from './pay'
import register from './register'
Vue.use(VueRouter)

const routes = [
  {
    path:"/",
    redirect:"/guidePage"
  },
  mv,    //
  search,   //
  cinema,   //
  my,   //
  download,   //
  guidePage,   //
  guidePageLike,   //
  hotDetailsPage,     //
  newDetailsPage,   //
  shanghai,  //电影院页面
  pay , //支付页面
  register
  
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
